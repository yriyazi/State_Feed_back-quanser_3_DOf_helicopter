clc
clear all
close all
%%

load 'parameters'

sim('helico_model.slx')
