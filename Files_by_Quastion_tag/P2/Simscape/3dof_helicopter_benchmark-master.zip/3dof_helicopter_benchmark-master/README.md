# 3dof_helicopter_benchmark

## How to run the model
In order to launch the Simulink/Simscape© implementation of the model and the controller proposed in the paper, run the `helico_main.m` script. It loads the simulation parameters and runs the `helico_model.slx` Simulink© model.
The model is developed in Matlab version R2017a.

## List of parameters
See the attached pdf.
